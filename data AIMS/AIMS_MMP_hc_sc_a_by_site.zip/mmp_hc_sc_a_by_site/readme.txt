This data and asssociated usage constraints are described here.
https://doi.org/10.25845/5cc64f29b35a1

Please cite as such
Australian Institute of Marine Science (AIMS). 2014, Great Barrier Reef Marine Monitoring Program - Coral (MMP), https://doi.org/10.25845/5cc64f29b35a1

For additional information see https://www.aims.gov.au/research-topics/monitoring-and-discovery/monitoring-great-barrier-reef

Copy this link below to view a map with the AIMS sectors and survey reefs:
https://apps.aims.gov.au/reef-monitoring/sector

Latest Reporting tool: https://apps.aims.gov.au/reef-monitoring/reefs



Data Dictionary for mmp_hc_sc_a_by-Site.csv - MMP photo transects for reef/depth/site data summarised by broad benthic groups for 2005-2019. This metadata is specifically for the publicly available MMP data file 'mmp_hc_sc_a_by_site.csv'.

Field Name	Description and comment
NRM_REGION:	One of four Natural Resource Management Regions currently in the MMP.
CATCHMENT:	The major catchment discharging into coastal waters of the region. The Wet Tropics NRM is divided into three sub-regions defined by the major local catchment; Daintree, Johnstone, Tully.

MMP_SITE_NAME:	Reef within the MMP monitoring program. At each reef there are two sites with similar aspect separated by at least 250m. Where the extension of reefal habitat is limited and it is not possible to establish two sites on the same reef, the second site is established on the next adjacent reef with appropriate habitat. For the MMP, sites on the western sides of Orpheus and Pelorus islands are combined as Palms West. Sites on the southern sides of Humpy and Halfway islands are combined as Keppels South.

DEPTH:		Depth (m) below lowest astronomical tide (LAT) of the transects. Two depths (2m, 5m) per site, two sites per reef. The transects follow the contours of the reef at either 2m or 5m below datum.

SITE_NO:	At each reef there are two sites with similar aspect separated by at least 250m. Where the extension of reefal habitat is limited and it is not possible to establish two sites on the same reef, the second site is established on the next adjacent reef with appropriate habitat. For the MMP, sites on the western sides of Orpheus and Pelorus islands are combined as Palms West. Sites on the southern sides of Humpy and Halfway islands are combined as Keppels South.

LATITUDE:	Latitude of the monitored community in decimal degrees
LONGITUDE:	Longitude of the monitored community in decimal degrees
P_CODE:		Project Code - AIMS use. Denotes survey program - for the MMP the P_CODE is IN for Inshore monitoring
VISIT_NO:	Sampling year code used for aggregating data. Ranging from Vist 1 = 2005 through to Visit 16 = 2020
YEAR_CODE:	Year in which the sampling took place. Ranges from 2005-2021
SAMPLE-DATE:	Date of sampling: dd/mm/yyyy
GROUP_CODE:	Photo transect data is summarised into four Benthic Groups; Algae (combined all algal forms including filamentous turf algae, fleshy macroalgae, and calcareous algae), Hard Coral (Order Scleractinia), Soft Coral (Order Alcyonacea and Helioporacea), Other - includes other benthic categories (e.g. sponge, tunicates, anthozoans, etc), and abiotics (e.g. rock, rubble, sand, silt, etc). 

COVER:		Percent cover (%) of the Benthic Group. The percent cover is based on the proportional representation of the nominated categories (Algae, Hard Coral, Soft Coral, Other)among all 160 points of each transect, averaged across all five transects for any given site and depth. Methodology is outlined in the annual Marine Monitoring Program Reports (i.e. Report for inshore coral monitoring 2019-2020) and adapted from Jonker et al 2008. For any given site and depth, the sum of the Benthic Groups = 100%

End of data dictionary.

Updated 21/06/2023